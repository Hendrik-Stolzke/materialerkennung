Dieses Package wurde erstellt für die Arbeit am Projekt Materialerkennung.
Mit Hilfe der Funktion 'prepare_data' werden alle csv-Dateien (die im selben Ordner (src) sein müssen wie die Datei wo die Funktion verwendet wird), in eine zusammengefasst, in ein DataFrame umgewandelt, jede einzelne Zeile bekommt eine ID un die Datei mit der Zielvariable wird für spätere Anwendung getrennt in Time Series umgewandelt.

Eventuell kommen da noch weitere Funktionen rein die wir benutzen werden aber erstmal versuche ich das überhauapt hinzubekommen...